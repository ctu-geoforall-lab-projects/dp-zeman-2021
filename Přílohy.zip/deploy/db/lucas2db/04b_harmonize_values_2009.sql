--
-- 2009
--
UPDATE lucas2009 SET nuts0 = '8' WHERE nuts0 = '';
UPDATE lucas2009 SET nuts1 = '8' WHERE nuts1 = '';
UPDATE lucas2009 SET nuts2 = '8' WHERE nuts2 = '';
UPDATE lucas2009 SET obs_direct= '8' WHERE obs_direct= '0';
UPDATE lucas2009 SET lc1_perc = '-1' WHERE lc1_perc = '0';
UPDATE lucas2009 SET lc2_perc = '-1' WHERE lc2_perc = '';
UPDATE lucas2009 SET lc2_perc = '8' WHERE lc2_perc = '0';
UPDATE lucas2009 SET tree_height_survey = '-1' WHERE tree_height_survey = '255';
UPDATE lucas2009 SET tree_height_survey = '-1' WHERE tree_height_survey = '';
UPDATE lucas2009 SET tree_height_survey = '8' WHERE tree_height_survey = '0';
UPDATE lucas2009 SET lndmng_plough = '8' WHERE lndmng_plough = '0';
UPDATE lucas2009 SET grazing = '-1' WHERE grazing = '3';
UPDATE lucas2009 SET soil_stones_perc = '8' WHERE soil_stones_perc = '0';
UPDATE lucas2009 SET feature_width = '8' WHERE feature_width = '0';
UPDATE lucas2009 SET feature_width = '-1' WHERE feature_width in ('','255');
UPDATE lucas2009 SET soil_taken = '8' WHERE soil_taken = '0';
UPDATE lucas2009 SET soil_taken = '4' WHERE soil_taken = '3';
UPDATE lucas2009 SET th_ew = '1' WHERE th_ew = 'E';
UPDATE lucas2009 SET th_ew = '2' WHERE th_ew = 'W';
UPDATE lucas2009 SET crop_residues = '22' WHERE crop_residues = '1';
UPDATE lucas2009 SET crop_residues = '1' WHERE crop_residues in ('2','3','4');
UPDATE lucas2009 SET crop_residues = '2' WHERE crop_residues = '22';
UPDATE lucas2009 SET crop_residues = '8' where crop_residues = '0';
UPDATE lucas2009 SET wm_source = '8' where wm_source = '0';
UPDATE lucas2009 SET wm_source = '-1' where wm_source in ('6','16','17','18','20','24');
UPDATE lucas2009 SET wm_type = '8' where wm_type = '0';
UPDATE lucas2009 SET wm_type = '-1' where wm_type in ('6','9','10','12','16','17','18','24');
UPDATE lucas2009 SET wm_delivery = '8' where wm_delivery = '0';
UPDATE lucas2009 SET wm_delivery = '-1' where wm_delivery in ('5','6','10','12');
UPDATE lucas2009 SET lc1_spec = UPPER(lc1_spec);
UPDATE lucas2009 SET lc2_spec = UPPER(lc2_spec);
UPDATE lucas2009 SET lc1_spec = '8' WHERE lc1_spec = '';
UPDATE lucas2009 SET lc1_spec = '-1' WHERE lc1_spec = 'X';
UPDATE lucas2009 SET lc2_spec = '8' WHERE lc2_spec = '';
UPDATE lucas2009 SET lc1_spec = 'B53B' WHERE lc1_spec = 'B53D';
UPDATE lucas2009 SET lc2_spec = 'B53B' WHERE lc2_spec = 'B53D';
UPDATE lucas2009 SET lc1_spec = 'C101' WHERE lc1_spec = 'C11';
UPDATE lucas2009 SET lc1_spec = 'C102' WHERE lc1_spec = 'C12';
UPDATE lucas2009 SET lc1_spec = 'C103' WHERE lc1_spec = 'C13';
UPDATE lucas2009 SET lc1_spec = 'C104' WHERE lc1_spec = 'C14';
UPDATE lucas2009 SET lc1_spec = 'C105' WHERE lc1_spec = 'C15';
UPDATE lucas2009 SET lc1_spec = 'C106' WHERE lc1_spec = 'C16';
UPDATE lucas2009 SET lc1_spec = 'C107' WHERE lc1_spec = 'C17';
UPDATE lucas2009 SET lc1_spec = 'C108' WHERE lc1_spec = 'C18';
UPDATE lucas2009 SET lc1_spec = 'C109' WHERE lc1_spec = 'C19';
UPDATE lucas2009 SET lc1_spec = 'C10A' WHERE lc1_spec = 'C1A';
UPDATE lucas2009 SET lc1_spec = 'C10B' WHERE lc1_spec = 'C1B';
UPDATE lucas2009 SET lc1_spec = 'C10C' WHERE lc1_spec = 'C1C';
UPDATE lucas2009 SET lc1_spec = 'C10D' WHERE lc1_spec = 'C1D';
UPDATE lucas2009 SET lc1_spec = 'C10E' WHERE lc1_spec = 'C1E';
UPDATE lucas2009 SET lc2_spec = 'C101' WHERE lc2_spec = 'C11';
UPDATE lucas2009 SET lc2_spec = 'C102' WHERE lc2_spec = 'C12';
UPDATE lucas2009 SET lc2_spec = 'C103' WHERE lc2_spec = 'C13';
UPDATE lucas2009 SET lc2_spec = 'C104' WHERE lc2_spec = 'C14';
UPDATE lucas2009 SET lc2_spec = 'C105' WHERE lc2_spec = 'C15';
UPDATE lucas2009 SET lc2_spec = 'C106' WHERE lc2_spec = 'C16';
UPDATE lucas2009 SET lc2_spec = 'C107' WHERE lc2_spec = 'C17';
UPDATE lucas2009 SET lc2_spec = 'C108' WHERE lc2_spec = 'C18';
UPDATE lucas2009 SET lc2_spec = 'C109' WHERE lc2_spec = 'C19';
UPDATE lucas2009 SET lc2_spec = 'C10A' WHERE lc2_spec = 'C1A';
UPDATE lucas2009 SET lc2_spec = 'C10B' WHERE lc2_spec = 'C1B';
UPDATE lucas2009 SET lc2_spec = 'C10C' WHERE lc2_spec = 'C1C';
UPDATE lucas2009 SET lc2_spec = 'C10D' WHERE lc2_spec = 'C1D';
UPDATE lucas2009 SET lc2_spec = 'C10E' WHERE lc2_spec = 'C1E';
UPDATE lucas2009 SET lc1_spec = 'C10E' WHERE lc1_spec in ('C21', 'C21E', 'C22', 'C23', 'C24', 'C25', 'C26', 'C27', 'C28', 'C29', 'C2A','C2B','C2C', 'C2D', 'C2E','C31', 'C32', 'C321', 'C325', 'C32A', 'C33', 'C34', 'C34', 'C35', 'C36', 'C37', 'C38', 'C39', 'C3A', 'C3B', 'C3C', 'C3D', 'C3E');
UPDATE lucas2009 SET lc2_spec = 'C10E' WHERE lc2_spec in ('C21', 'C21E', 'C22', 'C23', 'C24', 'C25', 'C26', 'C27', 'C28', 'C29', 'C2A','C2B','C2C', 'C2D', 'C2E','C31', 'C32', 'C321', 'C325', 'C32A', 'C33', 'C34', 'C34', 'C35', 'C36', 'C37', 'C38', 'C39', 'C3A', 'C3B', 'C3C', 'C3D', 'C3E');
UPDATE lucas2009 SET obs_dist = '8888' WHERE obs_dist = '88888';

--
-- LC harmonization
--
-- LC1
UPDATE lucas2009 SET lc1_h = 'Bx1' WHERE lc1 = 'BX1';
UPDATE lucas2009 SET lc1_h = 'Bx2' WHERE lc1 = 'BX2';
UPDATE lucas2009 SET lc1_h = '8' WHERE lc1 = 'C20';
UPDATE lucas2009 SET lc1_h = '8' WHERE lc1 = 'C30';
UPDATE lucas2009 SET lc1_h = '8' WHERE lc1 = 'F00';
UPDATE lucas2009 SET lc1_h = '8' WHERE lc1 = 'G10';
UPDATE lucas2009 SET lc1_h = '8' WHERE lc1 = 'G20';
-- LC2
UPDATE lucas2009 SET lc2_h = 'Bx1' WHERE lc2 = 'BX1';
UPDATE lucas2009 SET lc2_h = 'Bx2' WHERE lc2 = 'BX2';
UPDATE lucas2009 SET lc2_h = '8' WHERE lc2 = 'C20';
UPDATE lucas2009 SET lc2_h = '8' WHERE lc2 = 'C30';
UPDATE lucas2009 SET lc2_h = '8' WHERE lc2 = 'F00';
UPDATE lucas2009 SET lc2_h = '8' WHERE lc2 = 'G10';
UPDATE lucas2009 SET lc2_h = '8' WHERE lc2 = 'G20';

--
-- LU harmonization
--
-- LU1
UPDATE lucas2009 SET lu1_h = '8' WHERE lu1 = 'U340';
UPDATE lucas2009 SET lu1_h = 'U341' WHERE lu1 = 'U363';
UPDATE lucas2009 SET lu1_h = '8' WHERE lu1 = 'U400';
UPDATE lucas2009 SET lu1_h = '8' WHERE lu1 = 'U364';
-- LU2
UPDATE lucas2009 SET lu2_h = '8' WHERE lu2 = 'U340';
UPDATE lucas2009 SET lu2_h = 'U341' WHERE lu2 = 'U363';
UPDATE lucas2009 SET lu2_h = '8' WHERE lu2 = 'U400';
UPDATE lucas2009 SET lu2_h = '8' WHERE lu2 = 'U364';
