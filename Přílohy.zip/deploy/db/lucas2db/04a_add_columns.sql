-- LC
ALTER TABLE lucas${YEAR} ADD COLUMN lc1_h varchar;
ALTER TABLE lucas${YEAR} ADD COLUMN lc2_h varchar;
-- LU
ALTER TABLE lucas${YEAR} ADD COLUMN lu1_h varchar;
ALTER TABLE lucas${YEAR} ADD COLUMN lu2_h varchar;
