#!/usr/bin/env python3

import os

from parser import Parser
from merge_points import MergePoints

class MergeYears(MergePoints):
    def __init__(self, table, columns, primary_key, years):
        self.primary_key = primary_key

        super().__init__(table, columns, years)

    def build_sql(self):
        column_additionals = {
            "survey_year": {"dtype" : "integer", "value" : "EXTRACT(YEAR FROM survey_date)"},
        }
        
        print("BEGIN;")
        # print("DROP TABLE {} CASCADE;".format(self.table))
        print("CREATE TABLE {} ({} serial,{},{});".format(
            self.table, self.primary_key,
            ','.join(
                map(lambda x: '{} {}'.format(x, self.columns[x]["dtype"]), list(self.columns.keys()))),
            ','.join(
                map(lambda x: '{} {}'.format(x, column_additionals[x]["dtype"]), list(column_additionals.keys()))),
        ))

        for year in self.years:
            columns_year = []
            for name in self.columns.keys():
                if year not in self.columns[name]["exclude"]:
                    columns_year.append(name)

            print("DO $$ BEGIN RAISE NOTICE 'Processing {}'; END; $$;".format(year))
            print("INSERT INTO {t} ({c},{a}) (SELECT {c},{aa} FROM lucas{y});".format(
                t=self.table, c=','.join(columns_year),
                y=year, a=','.join(column_additionals.keys()),
                aa=','.join(
                    map(lambda x: column_additionals[x]["value"], list(column_additionals.keys()))),
            ))

        self.create_indices(["nuts0", "survey_date", "survey_year",
                             "geog_gps", "geom_gps", "geog_th", "geom_thr"]
        )

        print("COMMIT;")

if __name__ == "__main__":
    parser = Parser(
        args=[
            { 'dest': 'table', 'metavar': 'table', 'type': str,
              'help': 'Table name'
             },
            { 'dest': 'pkey', 'metavar': 'pkey', 'type': str,
              'help': 'Primary key'
             },
        ]
    )

    my = MergeYears(parser.table, parser.columns, parser.pkey,
                    range(parser.start_year, parser.end_year+1, 3)
    )
    my.build_sql()
