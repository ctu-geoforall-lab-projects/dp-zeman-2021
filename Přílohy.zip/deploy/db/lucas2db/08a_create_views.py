#!/usr/bin/env python3

from parser import Parser
from create_views import CreateViews

if __name__ == "__main__":
    parser = Parser(years=False,
        args=[
            { 'dest': 'groups', 'metavar': 'groups', 'type': str,
              'help': 'Groups to be processed'
            },
            { 'dest': 'table', 'metavar': 'table', 'type': str,
              'help': 'Table name'
            },
            { 'dest': 'pkey', 'metavar': 'pkey', 'type': str,
              'help': 'Primary key',
            },
            { 'dest': 'geom', 'metavar': 'geom', 'type': str,
              'help': 'Geometry column'
            }
        ]
    )

    cv = CreateViews(parser.columns, parser.groups, parser.table, parser.geom, parser.pkey)
    cv.build_sql()
