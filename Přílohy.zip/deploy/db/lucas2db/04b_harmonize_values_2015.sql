--
-- 2015
--
UPDATE lucas2015 SET nuts0 = '8' WHERE nuts0 = '';
UPDATE lucas2015 SET nuts1 = '8' WHERE nuts1 = '';
UPDATE lucas2015 SET nuts2 = '8' WHERE nuts2 = '';
UPDATE lucas2015 SET office_pi = '0' WHERE office_pi = '';
UPDATE lucas2015 SET lc1_perc = '1' WHERE lc1_perc = '2';
UPDATE lucas2015 SET lc1_perc = '2' WHERE lc1_perc = '3';
UPDATE lucas2015 SET lc1_perc = '3' WHERE lc1_perc = '4';
UPDATE lucas2015 SET lc1_perc = '4' WHERE lc1_perc = '5';
UPDATE lucas2015 SET lc1_perc = '5' WHERE lc1_perc = '6';
UPDATE lucas2015 SET lc1_perc = '5' WHERE lc1_perc = '7';
UPDATE lucas2015 SET lc2_perc = '1' WHERE lc2_perc = '2';
UPDATE lucas2015 SET lc2_perc = '2' WHERE lc2_perc = '3';
UPDATE lucas2015 SET lc2_perc = '3' WHERE lc2_perc = '4';
UPDATE lucas2015 SET lc2_perc = '4' WHERE lc2_perc = '5';
UPDATE lucas2015 SET lc2_perc = '5' WHERE lc2_perc = '6';
UPDATE lucas2015 SET lc2_perc = '5' WHERE lc2_perc = '7';
UPDATE lucas2015 SET lc_lu_special_remark = '22' WHERE lc_lu_special_remark = '1';
UPDATE lucas2015 SET lc_lu_special_remark = '1' WHERE lc_lu_special_remark = '2';
UPDATE lucas2015 SET lc_lu_special_remark = '2' WHERE lc_lu_special_remark = '22';
UPDATE lucas2015 SET lc_lu_special_remark = '100' WHERE lc_lu_special_remark = '7';
UPDATE lucas2015 SET lc_lu_special_remark = '88' WHERE lc_lu_special_remark = '8';
UPDATE lucas2015 SET lc_lu_special_remark = '8' WHERE lc_lu_special_remark = '9';
UPDATE lucas2015 SET lc_lu_special_remark = '9' WHERE lc_lu_special_remark = '10';
UPDATE lucas2015 SET lc_lu_special_remark = '10' WHERE lc_lu_special_remark = '100';
UPDATE lucas2015 SET obs_type = '8' WHERE obs_type = '5';
UPDATE lucas2015 SET parcel_area_ha = '-1' WHERE parcel_area_ha = '5';
UPDATE lucas2015 SET crop_residues = '22' WHERE crop_residues = '1';
UPDATE lucas2015 SET crop_residues = '1' WHERE crop_residues in ('2','3','4');
UPDATE lucas2015 SET crop_residues = '2' WHERE crop_residues = '22';
UPDATE lucas2015 SET lc1_spec = UPPER(lc1_spec);
UPDATE lucas2015 SET lc2_spec = UPPER(lc2_spec);

--
-- No LC harmonization applied
--

--
-- LU harmonization
--
-- LU1
UPDATE lucas2015 SET lu1_h = '8' WHERE lu1 = 'U340';
UPDATE lucas2015 SET lu1_h = '8' WHERE lu1 = 'U410';
-- LU2
UPDATE lucas2015 SET lu2_h = '8' WHERE lu2 = 'U340';
UPDATE lucas2015 SET lu2_h = '8' WHERE lu2 = 'U410';
