#!/usr/bin/env python3

import os

from parser import Parser
from merge_points import MergePoints

class AggregateST(MergePoints):
    def _get_columns(self, year, target=True):
        cols = []
        for col, item in self.columns.items():
            if year in item["exclude"]:
                continue
            if target:
                cols.append(col if col in self.timeless else '{}_{}'.format(col, year))
            else:
                cols.append(col)

        return cols
    
    def build_sql(self):
        print("BEGIN;")
        print("CREATE TABLE {} (".format(self.table), end='')
        # unique columns
        print(','.join(map(lambda x: '{} {}'.format(x, self.columns[x]["dtype"]), self.timeless)), end=',')
        columns_all = []
        for col in self.columns.keys():
            if col in self.timeless:
                continue
            for year in self.years:
                columns_all.append('{}_{} {}'.format(col, year, self.columns[col]["dtype"]))
        print(','.join(columns_all), end='')
        print(');')

        year = self.years[0]
        print("INSERT INTO {t} ({c1}) SELECT {c2} FROM lucas{y};".format(
            t=self.table, y=year,
            c1=','.join(self._get_columns(year, True)),
            c2=','.join(self._get_columns(year, False))
        ))

        key_column = "point_id"
        for year in self.years[1:]:
            # update existing points
            cols = self._get_columns(year, False)
            print("UPDATE {t} set {c3} "
                  "FROM (SELECT {c2} FROM lucas{y} WHERE {p} "
                  "IN (SELECT {p} FROM {t})) AS s WHERE {t}.{p}=s.{p};".format(
                      t=self.table, y=year,
                      c3=','.join(map(lambda x: '{x}_{y}=s.{x}'.format(x=x, y=year),
                                      set(cols).difference(self.timeless))),
                      c1=','.join(self._get_columns(year, True)),
                      c2=','.join(cols),
                      p=key_column
            ))
            # insert new points
            print("INSERT INTO {t} ({c1}) SELECT {c2} FROM lucas{y} WHERE NOT EXISTS "
                  "(SELECT 1 FROM {t} WHERE point_id = lucas{y}.point_id LIMIT 1);".format(
                      t=self.table, y=year,
                      c1=','.join(self._get_columns(year, True)),
                      c2=','.join(self._get_columns(year, False))
            ))
            

        self.create_indices(["nuts0", "survey_date",
                             "geog_gps", "geom_gps", "geog_th", "geom_thr"]
        )

        print("COMMIT;")

    def create_indices(self, columns):
        st_columns = []
        for col in columns:
            if col in self.timeless:
                st_columns.append(col)
            else:
                for year in self.years:
                    st_columns.append('{}_{}'.format(col, year))
        super().create_indices(st_columns)
        
        
if __name__ == "__main__":
    parser = Parser(
        args=[
            { 'dest': 'table', 'metavar': 'table', 'type': str,
              'help': 'Table name'
            }
        ]
    )

    my = AggregateST(parser.table, parser.columns,
                     range(parser.start_year, parser.end_year+1, 3)
    )
    my.build_sql()
