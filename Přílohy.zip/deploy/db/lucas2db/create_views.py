import os
import copy
from collections import OrderedDict

from osgeo import ogr

class CreateViews:
    def __init__(self, columns, groups, table, geom, pkey=None):
        # keep only selected geometry column
        cols = columns.keys()
        for col in list(cols):
            if col.startswith(('geog', 'geom')):
                del columns[col]

        self.columns = columns
        self.groups = groups.split(';')
        self.table = table
        self.pkey = pkey
        self.geom = geom
        self.survey_year = "survey_year"

    def _get_columns(self, name):
        return [name]
        
    def build_sql(self):
        print("SET search_path TO {},public;".format(os.environ["POSTGRES_SCHEMA"]))

        print("BEGIN;")
        for group in self.groups:
            self._create_view(group)
        # all
        self._create_view()

        print("COMMIT")

    def _create_view(self, group=None):
        if group:
            group_name = group.split(':')[0].lower()
            topics = group.split(':')[1].lower().split(',')
            view = '{}_{}'.format(self.table, group_name.replace(' ', '_').replace(',', '_'))
        else:
            view = self.table
            topics = None

        columns_view = []
        if self.pkey:
            columns_view.append(self.pkey)
        for name, item in self.columns.items():
            if item["group"] and (topics is None or (item["group"] == "default" or item["group"] in topics)):
                columns_view.extend(self._get_columns(name))
        if self.survey_year:
            columns_view.append(self.survey_year)
        columns_view.append('{} AS geom'.format(self.geom))
        print("CREATE VIEW {}.{} AS SELECT {} FROM {}.{};".format(
            os.environ["MAPSERVR_SCHEMA"], view,
            ','.join(columns_view),
            os.environ["POSTGRES_SCHEMA"], self.table
        ))


        
