#!/usr/bin/env python3

import os

start=None
end=None
for f in os.listdir('/data/points'):
   year = int(f.split('_')[1])
   if start is None:
       start = end = year
   else:
       if year < start:
           start=year
       elif year > end:
           end=year

with open("/tmp/start_end.env", "w") as fd:
   fd.write("START_YEAR={}\n".format(start))
   fd.write("END_YEAR={}".format(end))
