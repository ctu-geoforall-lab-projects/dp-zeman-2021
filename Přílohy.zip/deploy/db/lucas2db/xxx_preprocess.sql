-- fix 2006
delete from lucas2006 where surv_date like '88%'; -- skip one invalid measurement
alter table lucas2006 rename column surv_date to survey_date;

CREATE OR REPLACE FUNCTION lucas_preprocess(start_year integer,
                                            end_year integer)
  RETURNS void
AS $$
  for year in range(start_year, end_year+1, 3):
      plpy.info("Preprocessing on {}".format(year))
      # re-type attributes
      # TBD: moved to separated script
      plpy.execute("ALTER TABLE lucas{} ALTER COLUMN point_id TYPE integer USING point_id::integer".format(year))
      plpy.execute("ALTER TABLE lucas{} ALTER COLUMN survey_date TYPE date USING to_date(survey_date, 'DD/MM/YY')".format(year))
      plpy.execute("ALTER TABLE lucas{} ALTER COLUMN gps_long TYPE double precision USING gps_long::double precision".format(year))
      plpy.execute("ALTER TABLE lucas{} ALTER COLUMN gps_lat TYPE double precision USING gps_lat::double precision".format(year))

      # classes uppercase
      plpy.execute("UPDATE lucas{} SET lc1 = upper(lc1)".format(year))
      plpy.execute("UPDATE lucas{} SET lc2 = upper(lc2)".format(year))
      plpy.execute("UPDATE lucas{} SET lu1 = upper(lu1)".format(year))
      plpy.execute("UPDATE lucas{} SET lu2 = upper(lu2)".format(year))      

      # create indices
      plpy.execute("create index on lucas{} (point_id)".format(year))
$$ LANGUAGE plpython3u;

select lucas_preprocess(2006, 2018);
