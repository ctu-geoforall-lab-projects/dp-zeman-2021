--
-- 2012
--
UPDATE lucas2012 SET nuts0 = '8' WHERE nuts0 = '';
UPDATE lucas2012 SET nuts1 = '8' WHERE nuts1 = '';
UPDATE lucas2012 SET nuts2 = '8' WHERE nuts2 = '';
--UPDATE lucas2012 SET survey_date = -1 WHERE survey_date = '0001-01-01';
UPDATE lucas2012 SET lc1_perc = '1' WHERE lc1_perc = '2';
UPDATE lucas2012 SET lc1_perc = '2' WHERE lc1_perc = '3';
UPDATE lucas2012 SET lc1_perc = '3' WHERE lc1_perc = '4';
UPDATE lucas2012 SET lc1_perc = '4' WHERE lc1_perc = '5';
UPDATE lucas2012 SET lc1_perc = '5' WHERE lc1_perc = '6';
UPDATE lucas2012 SET lc2_perc = '1' WHERE lc2_perc = '2';
UPDATE lucas2012 SET lc2_perc = '2' WHERE lc2_perc = '3';
UPDATE lucas2012 SET lc2_perc = '3' WHERE lc2_perc = '4';
UPDATE lucas2012 SET lc2_perc = '4' WHERE lc2_perc = '5';
UPDATE lucas2012 SET lc2_perc = '5' WHERE lc2_perc = '6';
UPDATE lucas2012 SET tree_height_survey = '-1' WHERE tree_height_survey = '255';
UPDATE lucas2012 SET tree_height_maturity = '-1' WHERE tree_height_maturity = '255';
UPDATE lucas2012 SET lc_lu_special_remark = '22' WHERE lc_lu_special_remark = '1';
UPDATE lucas2012 SET lc_lu_special_remark = '1' WHERE lc_lu_special_remark = '2';
UPDATE lucas2012 SET lc_lu_special_remark = '2' WHERE lc_lu_special_remark = '22';
UPDATE lucas2012 SET lc_lu_special_remark = '10' WHERE lc_lu_special_remark = '7';
UPDATE lucas2012 SET photo_north = '-1' WHERE photo_north = '';
UPDATE lucas2012 SET photo_north = '-1' WHERE photo_north = '0';
UPDATE lucas2012 SET photo_east = '-1' WHERE photo_east = '';
UPDATE lucas2012 SET photo_east = '-1' WHERE photo_east = '0';
UPDATE lucas2012 SET photo_south = '-1' WHERE photo_south = '';
UPDATE lucas2012 SET photo_south = '-1' WHERE photo_south = '0';
UPDATE lucas2012 SET photo_west = '-1' WHERE photo_west = '';
UPDATE lucas2012 SET photo_west = '-1' WHERE photo_west = '0';
UPDATE lucas2012 SET feature_width = '-1' WHERE feature_width = '255';
UPDATE lucas2012 SET crop_residues = '22' WHERE crop_residues = '1';
UPDATE lucas2012 SET crop_residues = '1' WHERE crop_residues in ('2','3','4');
UPDATE lucas2012 SET crop_residues = '2' WHERE crop_residues = '22';
UPDATE lucas2012 SET lc1_spec = UPPER(lc1_spec);
UPDATE lucas2012 SET lc2_spec = UPPER(lc2_spec);
UPDATE lucas2012 SET lc1_spec = '8' WHERE lc1_spec = '6';
UPDATE lucas2012 SET lc1_spec = 'B53B' WHERE lc1_spec = 'B53D';
UPDATE lucas2012 SET lc2_spec = 'B53B' WHERE lc2_spec = 'B53D';

--
-- LC harmonization
--
-- LC1
UPDATE lucas2012 SET lc1_h = '8' WHERE lc1 = 'G10';
UPDATE lucas2012 SET lc1_h = '8' WHERE lc1 = 'G20';
-- LC2
UPDATE lucas2012 SET lc2_h = '8' WHERE lc2 = 'G10';
UPDATE lucas2012 SET lc2_h = '8' WHERE lc2 = 'G20';

--
-- LU harmonization
--
-- LU1
UPDATE lucas2012 SET lu1_h = '8' WHERE lu1 = 'U340';
UPDATE lucas2012 SET lu1_h = 'U341' WHERE lu1 = 'U363';
UPDATE lucas2012 SET lu1_h = '8' WHERE lu1 = 'U410';
-- LU2
UPDATE lucas2012 SET lu2_h = 'U341' WHERE lu2 = 'U363';
UPDATE lucas2012 SET lu2_h = '8' WHERE lu2 = 'U410';
UPDATE lucas2012 SET lu2_h = '8' WHERE lu2 = 'U340';
