--
-- 2006
--
UPDATE lucas2006 SET obs_radius = '8' WHERE obs_radius = '0';
UPDATE lucas2006 SET obs_direct = '8' WHERE obs_direct = '0';
UPDATE lucas2006 SET obs_dist = '1.5' WHERE gps_proj = '2' AND obs_dist = '1';
UPDATE lucas2006 SET obs_dist = '24.5' WHERE gps_proj = '2' AND obs_dist = '2';
UPDATE lucas2006 SET obs_dist = '75' WHERE gps_proj = '2' AND obs_dist = '3';
UPDATE lucas2006 SET obs_dist = '101' WHERE gps_proj = '2' AND obs_dist = '4';
UPDATE lucas2006 SET obs_dist = dist_gps_th WHERE gps_proj = '1';
UPDATE lucas2006 SET obs_type = '7' WHERE obs_type = '2';
UPDATE lucas2006 SET obs_type = '2' WHERE obs_type = '1' AND obs_dist::float > 100;
UPDATE lucas2006 set survey_date = '30/06/2006' WHERE survey_date = '88/88/2006';
 
--
-- LC harmonization
--
-- LC1
UPDATE lucas2006 SET lc1_h = 'C10' WHERE lc1 = 'C11';
UPDATE lucas2006 SET lc1_h = '8' WHERE lc1 = 'C12';
UPDATE lucas2006 SET lc1_h = '8' WHERE lc1 = 'C13';
UPDATE lucas2006 SET lc1_h = 'C10' WHERE lc1 = 'C21';
UPDATE lucas2006 SET lc1_h = '8' WHERE lc1 = 'C22';
UPDATE lucas2006 SET lc1_h = '8' WHERE lc1 = 'C23';
UPDATE lucas2006 SET lc1_h = 'D10' WHERE lc1 = 'D01';
UPDATE lucas2006 SET lc1_h = 'D20' WHERE lc1 = 'D02';
UPDATE lucas2006 SET lc1_h = 'E10' WHERE lc1 = 'E01';
UPDATE lucas2006 SET lc1_h = 'E20' WHERE lc1 = 'E02';
UPDATE lucas2006 SET lc1_h = '8' WHERE lc1 = 'F00';
UPDATE lucas2006 SET lc1_h = '8' WHERE lc1 = 'G01';
UPDATE lucas2006 SET lc1_h = '8' WHERE lc1 = 'G02';
UPDATE lucas2006 SET lc1_h = 'G30' WHERE lc1 = 'G03';
UPDATE lucas2006 SET lc1_h = 'G50' WHERE lc1 = 'G05';
-- LC2
UPDATE lucas2006 SET lc2_h = '8' WHERE lc2 = '0';
UPDATE lucas2006 SET lc2_h = 'C10' WHERE lc2 = 'C11';
UPDATE lucas2006 SET lc2_h = '8' WHERE lc2 = 'C12';
UPDATE lucas2006 SET lc2_h = '8' WHERE lc2 = 'C13';
UPDATE lucas2006 SET lc2_h = 'C10' WHERE lc2 = 'C21';
UPDATE lucas2006 SET lc2_h = '8' WHERE lc2 = 'C22';
UPDATE lucas2006 SET lc2_h = '8' WHERE lc2 = 'C23';
UPDATE lucas2006 SET lc2_h = 'D10' WHERE lc2 = 'D01';
UPDATE lucas2006 SET lc2_h = 'D20' WHERE lc2 = 'D02';
UPDATE lucas2006 SET lc2_h = 'E10' WHERE lc2 = 'E01';
UPDATE lucas2006 SET lc2_h = 'E20' WHERE lc2 = 'E02';
UPDATE lucas2006 SET lc2_h = '8' WHERE lc2 = 'F00';
UPDATE lucas2006 SET lc2_h = '8' WHERE lc2 = 'G01';
UPDATE lucas2006 SET lc2_h = '8' WHERE lc2 = 'G02';
UPDATE lucas2006 SET lc2_h = 'G30' WHERE lc2 = 'G03';
UPDATE lucas2006 SET lc2_h = 'G50' WHERE lc2 = 'G05';

--
-- LU harmonization
--
-- LU1
UPDATE lucas2006 SET lu1_h = '8' WHERE lu1 = '0';
UPDATE lucas2006 SET lu1_h = '8' WHERE lu1 = 'U340';
UPDATE lucas2006 SET lu1_h = 'U341' WHERE lu1 = 'U363';
UPDATE lucas2006 SET lu1_h = '8' WHERE lu1 = 'U400';
UPDATE lucas2006 SET lu1_h = '8' WHERE lu1 = 'U500';
-- LU2
UPDATE lucas2006 SET lu2_h = '8' WHERE lu2 = '0';
UPDATE lucas2006 SET lu2_h = '8' WHERE lu2 = 'U340';
UPDATE lucas2006 SET lu2_h = 'U341' WHERE lu2 = 'U363';
UPDATE lucas2006 SET lu2_h = '8' WHERE lu2 = 'U400';
UPDATE lucas2006 SET lu2_h = '8' WHERE lu2 = 'U500';
