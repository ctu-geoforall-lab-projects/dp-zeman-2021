--
-- create data schema
--

CREATE SCHEMA ${POSTGRES_SCHEMA};

--
-- create mapserver user && grant privileges
--
CREATE USER ${MAPSERVR_USER} with encrypted password '${MAPSERVR_PASSWD}';
-- schema: data
GRANT USAGE ON SCHEMA ${POSTGRES_SCHEMA} TO ${MAPSERVR_USER};
ALTER DEFAULT PRIVILEGES IN SCHEMA ${POSTGRES_SCHEMA}
      GRANT SELECT ON tables TO GROUP ${MAPSERVR_USER};
ALTER DEFAULT PRIVILEGES IN SCHEMA ${POSTGRES_SCHEMA}
      GRANT SELECT ON sequences TO GROUP ${MAPSERVR_USER};
-- schema: ms
CREATE SCHEMA ${MAPSERVR_SCHEMA};
GRANT USAGE ON SCHEMA ${MAPSERVR_SCHEMA} TO ${MAPSERVR_USER};
ALTER DEFAULT PRIVILEGES IN SCHEMA ${MAPSERVR_SCHEMA}
      GRANT SELECT ON tables TO GROUP ${MAPSERVR_USER};

--
-- clean-up (remove schemas introduced by docker image)
--
DROP SCHEMA tiger CASCADE;
DROP SCHEMA tiger_data CASCADE;
DROP SCHEMA topology CASCADE;

--
-- Add support for plpython3u
--
CREATE EXTENSION plpython3u;
