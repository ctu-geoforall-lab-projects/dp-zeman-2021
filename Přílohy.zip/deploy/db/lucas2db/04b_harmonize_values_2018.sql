--
-- 2018
--
UPDATE lucas2018 SET lc1_perc = '1' WHERE lc1_perc::int>=1 AND lc1_perc::int<10;
UPDATE lucas2018 SET lc1_perc = '2' WHERE lc1_perc::int>=10 AND lc1_perc::int<25;
UPDATE lucas2018 SET lc1_perc = '3' WHERE lc1_perc::int>=25 AND lc1_perc::int<50;
UPDATE lucas2018 SET lc1_perc = '4' WHERE lc1_perc::int>=50 AND lc1_perc::int<75;
UPDATE lucas2018 SET lc1_perc = '5' WHERE lc1_perc::int>=75 AND lc1_perc::int<=100;
UPDATE lucas2018 SET lc2_perc = '1' WHERE lc2_perc::int>=1 AND lc2_perc::int<10;
UPDATE lucas2018 SET lc2_perc = '2' WHERE lc2_perc::int>=10 AND lc2_perc::int<25;
UPDATE lucas2018 SET lc2_perc = '3' WHERE lc2_perc::int>=25 AND lc2_perc::int<50;
UPDATE lucas2018 SET lc2_perc = '4' WHERE lc2_perc::int>=50 AND lc2_perc::int<75;
UPDATE lucas2018 SET lc2_perc = '5' WHERE lc2_perc::int>=75 AND lc2_perc::int<=100;
UPDATE lucas2018 SET lc2_perc = '8' where lc2_perc::int=88888;
UPDATE lucas2018 SET lc2_perc = '-1' WHERE lc2_perc::int>100;
UPDATE lucas2018 SET lu1_perc = '1' WHERE lu1_perc::int>=1 AND lu1_perc::int<5;
UPDATE lucas2018 SET lu1_perc = '2' WHERE lu1_perc::int>=5 AND lu1_perc::int<10;
UPDATE lucas2018 SET lu1_perc = '3' WHERE lu1_perc::int>=10 AND lu1_perc::int<25;
UPDATE lucas2018 SET lu1_perc = '4' WHERE lu1_perc::int>=25 AND lu1_perc::int<50;
UPDATE lucas2018 SET lu1_perc = '5' WHERE lu1_perc::int>=50 AND lu1_perc::int<75;
UPDATE lucas2018 SET lu1_perc = '6' WHERE lu1_perc::int>=75 AND lu1_perc::int<90;
UPDATE lucas2018 SET lu1_perc = '7' WHERE lu1_perc::int>=90 AND lu1_perc::int<=100;
UPDATE lucas2018 SET lu1_perc = '8' where lu1_perc::int=88888;
UPDATE lucas2018 SET lu1_perc = '-1' WHERE lu1_perc::int>100;
UPDATE lucas2018 SET lu2_perc = '1' WHERE lu2_perc::int>=1 AND lu2_perc::int<5;
UPDATE lucas2018 SET lu2_perc = '2' WHERE lu2_perc::int>=5 AND lu2_perc::int<10;
UPDATE lucas2018 SET lu2_perc = '3' WHERE lu2_perc::int>=10 AND lu2_perc::int<25;
UPDATE lucas2018 SET lu2_perc = '4' WHERE lu2_perc::int>=25 AND lu2_perc::int<50;
UPDATE lucas2018 SET lu2_perc = '5' WHERE lu2_perc::int>=50 AND lu2_perc::int<75;
UPDATE lucas2018 SET lu2_perc = '6' WHERE lu2_perc::int>=75 AND lu2_perc::int<90;
UPDATE lucas2018 SET lu2_perc = '7' WHERE lu2_perc::int>=90 AND lu2_perc::int<=100;
UPDATE lucas2018 SET lu2_perc = '8' where lu2_perc::int=88888;
UPDATE lucas2018 SET lu2_perc = '-1' WHERE lu2_perc::int>100;
UPDATE lucas2018 SET soil_stones_perc = '1' WHERE soil_stones_perc::int>=1 AND soil_stones_perc::int<10;
UPDATE lucas2018 SET soil_stones_perc = '2' WHERE soil_stones_perc::int>=10 AND soil_stones_perc::int<25;
UPDATE lucas2018 SET soil_stones_perc = '3' WHERE soil_stones_perc::int>=25 AND soil_stones_perc::int<50;
UPDATE lucas2018 SET soil_stones_perc = '4' WHERE soil_stones_perc::int>=50 AND soil_stones_perc::int<=100;
UPDATE lucas2018 SET parcel_area_ha = '1' WHERE parcel_area_ha = '2';
UPDATE lucas2018 SET parcel_area_ha = '2' WHERE parcel_area_ha = '3';
UPDATE lucas2018 SET parcel_area_ha = '3' WHERE parcel_area_ha = '4';
UPDATE lucas2018 SET parcel_area_ha = '4' WHERE parcel_area_ha = '5';
UPDATE lucas2018 SET car_latitude = '-1' WHERE car_latitude = '0';
UPDATE lucas2018 SET car_longitude = '-1' WHERE car_longitude = '0';
UPDATE lucas2018 SET lc1_spec = UPPER(lc1_spec);
UPDATE lucas2018 SET lc2_spec = UPPER(lc2_spec);
UPDATE lucas2018 SET obs_dist = '8888' WHERE obs_dist ='';
UPDATE lucas2018 SET soil_stones_perc = '8' where soil_stones_perc = '888';


--
-- No LC harmonization applied
--

--
-- No LU harmonization applied
--
