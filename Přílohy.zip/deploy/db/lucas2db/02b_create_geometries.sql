-- fix coordinates for 2009
-- https://gitlab.com/geoharmonizer_inea/planning/-/issues/49#note_406829967
update lucas2009 set th_long = th_long * -1 from
(select ogc_fid as id from lucas2009 where th_ew = '2') as s
where ogc_fid = s.id;
update lucas2009 set geog_th = st_setsrid(st_point(th_long,th_lat),4326) from
(select ogc_fid as id from lucas2009 where th_ew = '2') as s
where ogc_fid = s.id;

--
-- LUCAS points:
--
--  add additional geometries (geog_gps, geom_gps, geom_thr)
--  round coordinates (geom_thr)
--  compute distance attributes (dist_gps_th, dist_th_thr)
--  create spatial indices
CREATE OR REPLACE FUNCTION lucas_geometries(start_year integer,
                                            end_year integer)
  RETURNS void
AS $$
  for year in range(start_year, end_year+1, 3):
      plpy.info("Geometries on {}".format(year))

      # geog_gps (4326)
      plpy.execute("ALTER TABLE lucas{0} ALTER COLUMN {1} TYPE {2} using {1}::{2}".format(year, "gps_long", "double precision"))
      plpy.execute("ALTER TABLE lucas{0} ALTER COLUMN {1} TYPE {2} using {1}::{2}".format(year, "gps_lat", "double precision"))
      plpy.execute("UPDATE lucas{0} SET gps_long = gps_long * -1 FROM (SELECT ogc_fid as id from lucas{0} WHERE gps_ew = '2') as S WHERE ogc_fid = s.id".format(year))
      plpy.execute("ALTER TABLE lucas{} ADD COLUMN geog_gps geography(point, 4326)".format(year))
      plpy.execute("UPDATE lucas{} SET geog_gps = st_setsrid(st_geomfromtext('POINT(' || gps_long || ' ' || gps_lat || ')'), 4326)::geography".format(year))
      # geom_gps (3035)
      plpy.execute("ALTER TABLE lucas{} ADD COLUMN geom_gps geometry(point, 3035)".format(year))
      plpy.execute("UPDATE lucas{} SET geom_gps = st_transform(geog_gps::geometry, 3035)".format(year))
      # geom_thr (3035)
      plpy.execute("ALTER TABLE lucas{} ADD COLUMN geom_thr geometry(point, 3035)".format(year))
      plpy.execute("UPDATE lucas{} SET geom_thr = st_transform(geog_th::geometry, 3035)".format(year))
      # geom_thr -> round coordinates
      plpy.execute("UPDATE lucas{} SET geom_thr = st_setsrid(st_point((st_x(geom_thr) / 1000)::int * 1000, (st_y(geom_thr) / 1000)::int * 1000), 3035)".format(year))
      
      # compute distance attributes (dist_gps_th, dist_th_thr)
      plpy.execute("ALTER TABLE lucas{} ADD COLUMN dist_gps_th double precision".format(year))
      plpy.execute("UPDATE lucas{} SET dist_gps_th = abs(st_distance(geog_th, geog_gps)) WHERE gps_proj = '1'".format(year))
      plpy.execute("ALTER TABLE lucas{} ADD COLUMN dist_th_thr double precision".format(year))
      plpy.execute("UPDATE lucas{} SET dist_th_thr = abs(st_distance(st_transform(geog_th::geometry, 3035), geom_thr))".format(year))

      # create spatial indices
      plpy.execute("CREATE index ON lucas{} USING gist (geog_gps)".format(year))
      plpy.execute("CREATE index ON lucas{} USING gist (geom_gps)".format(year))
      plpy.execute("CREATE index ON lucas{} USING gist (geom_thr)".format(year))
      
      ### plpy.commit() # TBD: invalid - why?
$$ LANGUAGE plpython3u;

SELECT lucas_geometries(${START_YEAR}, ${END_YEAR});

--
-- grid
--
-- round coordinates (grid)
ALTER TABLE grid ADD COLUMN geom_thr geometry(point, 3035);
UPDATE grid SET geom_thr = st_transform(geog_th::geometry, 3035);
UPDATE grid SET geom_thr = st_setsrid(st_point((st_x(geom_thr) / 1000)::int * 1000, (st_y(geom_thr) / 1000)::int * 1000), 3035);
-- re-type
ALTER TABLE grid ALTER COLUMN point_id TYPE integer USING point_id::integer;
-- create indices
CREATE INDEX on grid (point_id);
CREATE INDEX ON grid USING gist (geom_thr);
