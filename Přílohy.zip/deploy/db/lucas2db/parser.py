import csv
import argparse
from collections import OrderedDict

class Parser:
    def __init__(self, years=True, args=[]):
        parser = argparse.ArgumentParser()
        parser.add_argument('csv_file', metavar='csv_file', type=str,
                            help='Path to input CSV file')
        self._known_attrs = ["csv_file"]
        if years:
            parser.add_argument('start_year', metavar='start_year', type=int,
                                help='Start year to be processed')
            parser.add_argument('end_year', metavar='end_year', type=int,
                                help='End year to be processed')
            self._known_attrs.extend(["start_year", "end_year"])

        for arg in args:
            parser.add_argument(**arg)
            self._known_attrs.append(arg['dest'])
    
        self._args = parser.parse_args()
        
    @staticmethod
    def read_csv(csv_file):
        """Read CSV file.

        :return list, list: two column returned as lists
        """
        columns = OrderedDict()
        with open(csv_file, newline='') as fd:
            reader = csv.DictReader(fd, delimiter=';')
            for row in reader:
                # https://stackoverflow.com/questions/1885324/is-it-possible-to-keep-the-column-order-using-csv-dictreader
                sorted_row = OrderedDict(sorted(row.items(),
                                                key=lambda item: reader.fieldnames.index(item[0])))
                key = list(sorted_row.keys())
                columns[sorted_row[key[0]].lower()] = { key[1].lower(): sorted_row[key[1]].lower() }

        return columns

    def __getattr__(self, attr):
        if attr in self._known_attrs:
            return self._args.__getattribute__(attr)
        elif attr == "columns":
            return self.read_csv(self._args.csv_file)
        else:
            raise Exception("Invalid attribute {}".format(attr))
        
