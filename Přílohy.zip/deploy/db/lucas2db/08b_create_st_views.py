#!/usr/bin/env python3

from parser import Parser
from create_views import CreateViews
from merge_points import ColumnTypes

class CreateViewsST(CreateViews, ColumnTypes):
    def __init__(self, columns, groups, table, geom, start_year, end_year):
        super().__init__(columns, groups, table, geom)
        ColumnTypes.__init__(self, columns, list(range(start_year, end_year+1, 3)))
        
        self.survey_year = None

    def _get_columns(self, name):
        cols = []
        item = self.columns[name]
        if name in self.timeless:
            cols.append(name)
        else:
            for year in self.years:
                cols.append('{}_{}'.format(name, year))

        return cols
        
if __name__ == "__main__":
    parser = Parser(years=True,
        args=[
            { 'dest': 'groups', 'metavar': 'groups', 'type': str,
              'help': 'Groups to be processed'
            },
            { 'dest': 'table', 'metavar': 'table', 'type': str,
              'help': 'Table name'
            },
            { 'dest': 'geom', 'metavar': 'geom', 'type': str,
              'help': 'Geometry column'
            }
        ]
    )

    cv = CreateViewsST(parser.columns, parser.groups, parser.table, parser.geom, parser.start_year, parser.end_year)
    cv.build_sql()
