#!/bin/bash -e

export DIR=/opt/lucas2db
export DATA_DIR=/data

function run_psql {
    if test -z $1 ; then
        # stdin
        PGOPTIONS=--search_path=${POSTGRES_SCHEMA},public psql \
                 -d $POSTGRES_DB
    else
        envsubst \
            '$POSTGRES_SCHEMA $MAPSERVR_SCHEMA $MAPSERVR_USER $MAPSERVR_PASSWD $START_YEAR $END_YEAR $YEAR' \
            < $1 | \
            PGOPTIONS=--search_path=${POSTGRES_SCHEMA},public psql \
                     -d $POSTGRES_DB
    fi
}

function section_begin {
    echo "----------------------------------------------------------------"
    echo $1
    echo "----------------------------------------------------------------"
    SECONDS=0
}

function section_end {
    SECONDS_DEPLOY=$(($SECONDS_DEPLOY + $SECONDS))
    time_elapsed $SECONDS
}

function time_elapsed {
    echo "TIME ELAPSED: $(( ${1} / 3600 ))h $(( (${1} / 60) % 60 ))m $(( ${1} % 60 ))s"
}

# 00.
SECONDS_DEPLOY=0
section_begin "(00) Database initialization"
#  get START_YEAR and END_YEAR variables
### https://gitlab.com/ctu-geoforall-lab/ctu-geoharmonizer/-/issues/119
### eval `python3 $DIR/00a_scan_data.py`
run_psql $DIR/00b_init.sql

# import from dump (if exists) and exit
if test -f ${DATA_DIR}/dump.sql ; then
    run_psql ${DATA_DIR}/dump.sql
    exit 0
fi

# 01.
section_begin "(01) Import LUCAS data into database"
$DIR/01a_data_import.sh
section_end

# 02.
section_begin "(02) LUCAS points coordinates correction"
run_psql $DIR/02a_harmonize_gps_values.sql
run_psql $DIR/02b_create_geometries.sql
echo "Computing dist_thr_grid..."
for YEAR in `seq $START_YEAR 3 $END_YEAR`; do
    echo "Processing ${YEAR}..."
    export YEAR=$YEAR # required by envsubst
    run_psql $DIR/02c_dist_thr_grid.sql
done
section_end

# 03.
section_begin "(03) Harmonization step 1 - rename attributes"
python3 $DIR/03a_rename_attributes.py $DIR/03a_rename_attributes.csv \
        $START_YEAR $END_YEAR | \
        run_psql
section_end

# 04.
section_begin "(04) Harmonization step 2 - values harmonization"
for YEAR in `seq $START_YEAR 3 $END_YEAR`; do
    echo "Processing ${YEAR}..."
    export YEAR=$YEAR # required by envsubst
    run_psql $DIR/04a_add_columns.sql
    if test -f $DIR/04b_harmonize_values_${YEAR}.sql ; then
       run_psql $DIR/04b_harmonize_values_${YEAR}.sql
    fi
    run_psql $DIR/04c_harmonize_lc_lu.sql
done
section_end

# 05.
section_begin "(05) Harmonization step 3 - retype attributes"
python3 $DIR/05a_retype_attributes.py $DIR/05a_retype_attributes.csv \
        $START_YEAR $END_YEAR | \
        run_psql
section_end

# 06.
section_begin "(06) Merge LUCAS points by years"
python3 $DIR/06a_merge_years.py $DIR/06a_list_attributes.csv \
        $START_YEAR $END_YEAR $TABLE_NAME $TABLE_PRIMARY_KEY | \
        run_psql
section_end

# 07.
section_begin "(07) Perform space-time aggregation"
python3 $DIR/07a_aggregate_st.py $DIR/06a_list_attributes.csv \
        $START_YEAR $END_YEAR $TABLE_NAME_ST | \
        run_psql
section_end

# 08.
section_begin "(08) Publish data"
python3 $DIR/08a_create_views.py $DIR/06a_list_attributes.csv \
	"$GROUPS" $TABLE_NAME $TABLE_PRIMARY_KEY $TABLE_GEOMETRY | \
        run_psql
python3 $DIR/08b_create_st_views.py $DIR/06a_list_attributes.csv \
	$START_YEAR $END_YEAR "$GROUPS" $TABLE_NAME_ST $TABLE_GEOMETRY | \
        run_psql
section_end

# xx.
section_begin "(xx) Database deployment successfuly finished"
pg_dump -U postgres -d $POSTGRES_DB > ${DATA_DIR}/dump.sql
time_elapsed $SECONDS_DEPLOY

exit 0
